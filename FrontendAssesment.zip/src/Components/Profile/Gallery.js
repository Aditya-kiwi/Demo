import React from "react";

const UserGallery = () => {
  return <div className="coming-soon"><h1>Comming Soon</h1></div>;
};
export default UserGallery;
