import React from "react";

const UserPost = () => {
  return <div className="coming-soon"><h1>Comming Soon</h1></div>;
};
export default UserPost;
