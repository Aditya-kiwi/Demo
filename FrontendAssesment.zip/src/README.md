*dependencies - 
1- react router dom
2- react infinite scroller
3- node sass for css (sass)
4- react bootstrap for ui

--Node verion i have used in this project is 19.14.0
--Note you need install all these packages to run this project or jsut run npi install